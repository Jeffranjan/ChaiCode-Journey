var shipName = "The Amber";
console.log("Shipname: ", shipName);

let crewCount = 12;
console.log("crew count: ", crewCount);
crewCount = 14;

const captainName = "Jack Sparrow";
console.log("Captain Name: ", captainName);
// captainName = "Dipesh";

if (true) {
  var leakyTreasure = "Gold coins";
}

for (var i = 0; i < 10; i++) {
  //
}
for (let j = 0; i < 10; i++) {
  //
}

console.log(leakyTreasure);

let shipSpeed = 22;
let _privatelog = "secret";
let MONGODB_URI = "";
let name = "hitesh";

const treasureChest = {
  gold: 100,
  rubies: 50,
  maps: 2,
};

treasureChest.gold = 150;
// treasureChest = { gold: 50 };

const crewRoster = ["Alok", "Abhinav", "Tasnish"];
crewRoster.push("vraj");
crewRoster[0] = "Shubham";

crewRoster = ["Someone"];
